import React, {useState} from 'react'
import {View, Text, Button, Image, StyleSheet} from 'react-native' //ESTRUTURA
import {CustomButton} from './CustomButton';

export default function App (){
  
  const[contagem, setContagem]= useState(0)

  function incrementarContagem(){
    setContagem(contagem + 1)
  }
  function decrementarContagem(){
    if(contagem <=0){
      return
    }
    setContagem(contagem - 1)
  }
    return(
    <View style={styles.container}>
      <View style={styles.logoContainer}>
          <Image 
          source={require('./assets/contador.png')} style={styles.logo}/>
      </View>
      
      <Text 
        style= {styles.contador}>
        {contagem}
      </Text>

      <Button
          title='MAIS'
          color='#7DDE92'
          onPress={incrementarContagem}
      />
         
      <Button
          title='MENOS'
          color='#3ABEFF'
          onPress={decrementarContagem}
      />
      
    </View>
  )
}


const styles= StyleSheet.create({
  container:{
    width:'100%', 
    height:'100%',
    backgroundColor: '#1f1f1f',
    paddingHorizontal:16
    
  },
  logoContainer: {
    alignItems: "center",
    padding:100,
    paddingBottom:0
    
  },
  logo:{
    width:250,
    height:200
  },
  contador:{
    fontSize:150,
    textAlign:'center',
    color:'white',
    paddingTop:0,
    paddingVertical:20,
    paddingBottom:30,
  },

});



//<View style={styles.logoContainer}>
//          <Image 
//          source={require('./assets/logo-contador.png')} style={styles.logo}/>
//        </View>