const styles= StyleSheet.create({
  container:{
    width:'100%', 
    height:'100%',
    backgroundColor: '#1f1f1f',
    paddingHorizontal:16
    
    

  },
  logoContainer: {
    alignItems: "center",
    padding:100,
    paddingBottom:0
    

  },
  logo:{
    width:200,
    height:200
  },
  contador:{
    fontSize:100,
    textAlign:'center',
    color:'white',
    paddingTop:0,
    paddingVertical:50,
    paddingBottom:0,
  },

});