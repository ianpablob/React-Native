import {StyleSheet} from 'react-native';

const styles= StyleSheet.create({
  container:{
    flex:1,
    alignItems:'center',
    justifyContent:'center',
    paddingVertical: 10,
    paddingHorizontal:20,
    borderRadius:8,
    backgroundColor:'#c6c6',
   },
    input:{
    padding: 18,
    backgroundColor:'pink',
    marginTop: 20
   },
   button:{
     backgroundColor:'yellow',
     padding:10,
     alignItems:'center'
   },
   text:{
     fontSize:20,
     color:'blue',
     fontWeight:'bold'
   }
})

export default styles;