import React from 'react';
import { Text, View, TouchableOpacity, StyleSheet } from 'react-native';
import styles from './styles'

export default function CustomButton(props) {
  return (
    <TouchableOpacity onPress={()=>props.click()}>
        <View style={styles.button}>
            <Text style={styles.Text}>{props.name}</Text>
        </View>
    </TouchableOpacity>
  );
}
